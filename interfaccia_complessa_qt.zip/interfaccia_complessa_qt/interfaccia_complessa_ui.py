# Questo è un file generato automaticamente da pyuic5
# È un esempio semplificato

from PyQt5 import QtCore, QtGui, QtWidgets

class Ui_MainWindow(object):
    def setupUi(self, MainWindow):
        MainWindow.setWindowTitle("Interfaccia Complessa")
        MainWindow.resize(400, 300)
        self.centralwidget = QtWidgets.QWidget(MainWindow)
        self.lineEditNome = QtWidgets.QLineEdit(self.centralwidget)
        self.lineEditNome.setGeometry(20, 20, 200, 25)
        self.comboColori = QtWidgets.QComboBox(self.centralwidget)
        self.comboColori.setGeometry(20, 60, 200, 25)
        self.comboColori.addItems(["rosso", "verde", "blu"])
        self.checkBoxOK = QtWidgets.QCheckBox("Accetto i termini", self.centralwidget)
        self.checkBoxOK.setGeometry(20, 100, 200, 20)
        self.pushButtonAdd = QtWidgets.QPushButton("Aggiungi", self.centralwidget)
        self.pushButtonAdd.setGeometry(20, 130, 100, 30)
        self.tableWidget = QtWidgets.QTableWidget(self.centralwidget)
        self.tableWidget.setGeometry(20, 170, 360, 100)
        self.tableWidget.setColumnCount(2)
        self.tableWidget.setHorizontalHeaderLabels(["Nome", "Colore"])
        self.labelStatus = QtWidgets.QLabel(self.centralwidget)
        self.labelStatus.setGeometry(150, 135, 220, 20)
        MainWindow.setCentralWidget(self.centralwidget)
