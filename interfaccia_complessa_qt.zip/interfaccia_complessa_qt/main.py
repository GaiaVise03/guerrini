import sys
from PyQt5.QtWidgets import QApplication, QMainWindow, QTableWidgetItem
from interfaccia_complessa_ui import Ui_MainWindow

class AppComplessa(QMainWindow):
    def __init__(self):
        super().__init__()
        self.ui = Ui_MainWindow()
        self.ui.setupUi(self)
        self.ui.pushButtonAdd.clicked.connect(self.aggiungi_dati)

    def aggiungi_dati(self):
        nome = self.ui.lineEditNome.text()
        colore = self.ui.comboColori.currentText()
        accettato = self.ui.checkBoxOK.isChecked()

        if not nome:
            self.ui.labelStatus.setText("❗ Inserisci il nome.")
            return
        if not accettato:
            self.ui.labelStatus.setText("❗ Devi accettare i termini.")
            return

        row = self.ui.tableWidget.rowCount()
        self.ui.tableWidget.insertRow(row)
        self.ui.tableWidget.setItem(row, 0, QTableWidgetItem(nome))
        self.ui.tableWidget.setItem(row, 1, QTableWidgetItem(colore))

        self.ui.labelStatus.setText("✅ Dati aggiunti con successo.")
        self.ui.lineEditNome.clear()
        self.ui.checkBoxOK.setChecked(False)

if __name__ == "__main__":
    app = QApplication(sys.argv)
    finestra = AppComplessa()
    finestra.show()
    sys.exit(app.exec_())
