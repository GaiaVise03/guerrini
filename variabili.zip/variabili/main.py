#necessario per usare comandi json
import json
def saveJSON():
    txjson= json.dumps(elenco)
    f= open("elenco.json","w")
    f.write(txjson)
    f.close()

def openJSON():
    try:
        f= open("elenco.json")
        txjson=f.read()
        elenco=json.loads(txjson)
        f.close()
    except:
        print("file non trovato")


#stampa
def stampa():
    print("---stampa----")
    for scheda in elenco:
        print(f"cog:{scheda['cognome']} nom: {scheda['nome']}")

#stampa
def aggiungi():
    print("---aggiungi----")
    nome= input("ins nome: ")
    cognome= input("ins cognome: ")
    anno= input("ins anno nascita: ")
    anno = int(anno)
    scheda={"cognome": cognome,
    "nome":nome,
    "anno": anno}
    elenco.append(scheda)
    
#stampa
def trova():
    print("---trova----")
    cognomefind= input("chi cerchi? ")
    trovato=False
    for myscheda in elenco:
        mycog=myscheda["cognome"]
        if mycog == cognomefind:
            print("TROVATO!!!!", mycog, myscheda["nome"])
            trovato=True
    
    if trovato==False:
        print("non trovato")

def menu():
    print("a: aggiungi -","s: stampa -","t: trova -","x: esci" )


#variabili globali programma
#elenco dictionary
elenco = []
openJSON()
#inizio programma main

print("___PROGRAMMA ELENCO DICTIONARY___")


while True:
    menu()
    choice= input("inserire comando: ")
    if choice.lower()=="a":
        aggiungi()
    if choice.lower()=="s":
        stampa()
    if choice.lower()=="t":
        trova()
    if choice.lower()=="j":
        saveJSON()
    if choice.lower()=="x":
        print("ARRIVEDERCI")
        break
print("fine programma")
    

